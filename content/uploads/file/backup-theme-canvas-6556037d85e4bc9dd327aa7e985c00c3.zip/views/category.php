<?php defined('BASEPATH') OR exit('No direct script access allowed');?>
<!-- 
*******************************************************
	Include Header Template
******************************************************* 
-->
<?php include_once('header.php'); ?>
<!-- End Header -->

<!-- 
*******************************************************
	Insert Content
******************************************************* 
-->
<section id="page-title">
	<div class="container clearfix">
		<h1><?=$result_category['title']?></h1>
		<ol class="breadcrumb">
			<li class="breadcrumb-item"><a href="<?= site_url(); ?>">Home</a></li>
			<li class="breadcrumb-item"><a href="<?= site_url('index'); ?>">Category</a></li>
			<li class="breadcrumb-item active" aria-current="page"><?=$result_category['title']?></li>
		</ol>
	</div>
</section>

<section id="content">
	<div class="content-wrap">
		<div class="container clearfix">
			<div class="row">
				<div class="col-lg-8 nobottommargin clearfix">
					<div id="posts" class="small-thumbs">
						<?php foreach ($data_post as $res): ?>
						<div class="entry clearfix">
							<div class="entry-image">
								<a href="<?=post_url($res['post_seotitle']);?>" title="<?=$res['post_title'];?>">
									<img class="image_fade" src="<?=post_images($res['picture'],'medium',TRUE);?>" alt="<?=$res['post_title'];?>">
								</a>
							</div>
							<div class="entry-c">
								<div class="entry-title">
									<h2>
										<a href="<?=post_url($res['post_seotitle']);?>" title="<?=$res['post_title'];?>"><?=$res['post_title'];?></a>
									</h2>
								</div>
								<ul class="entry-meta clearfix">
									<li><i class="icon-calendar3"></i> <?=ci_date($res['datepost'].$res['timepost'], 'l, d F Y');?></li>
									<li><i class="icon-folder-open"></i> <a href="<?=site_url('category/'.$res['category_seotitle']);?>"><?=$res['category_title'];?></a></li>
									<li><i class="icon-eye"></i> <?=$res['hits'];?></li>
								</ul>
								<div class="entry-content">
									<p><?=cut($res['content'],150);?>...</p>
									<a href="<?=post_url($res['post_seotitle']);?>" class="more-link">Read More</a>
								</div>
							</div>
						</div>
						<?php endforeach ?>
					</div>

					<div class="row mb-3">
						<div class="col-12">
							<ul class="pagination justify-content-center">
								<?=$page_link;?>
							</ul>
						</div>
					</div>
				</div>

				<!-- Sidebar -->
				<div class="col-lg-4 nobottommargin col_last clearfix">
					<!-- Include Sidebar -->
					<?php include_once('sidebar.php'); ?>
					<!--/ Include Sidebar -->
				</div>
				<!--/ sidebar -->
			</div>
		</div>
	</div>
</section>
<!-- End Content -->

<!-- 
*******************************************************
	Include Footer Template
******************************************************* 
-->
<?php include_once('footer.php'); ?>
<!-- End Footer -->